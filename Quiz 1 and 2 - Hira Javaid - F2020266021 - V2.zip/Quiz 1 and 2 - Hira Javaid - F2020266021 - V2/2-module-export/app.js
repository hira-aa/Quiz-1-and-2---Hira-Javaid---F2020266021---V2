// console.log("Connected");

const data = require("./math");

// console.log(data.cube(5));
// console.log(data.PI);
console.log(data.student[1]);
